package tsomaia.ia.ge.mbank.ui.loginpage;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.ui.loginpage.implementations.GetUsersInteractorImpl;
import tsomaia.ia.ge.mbank.ui.loginpage.implementations.MainPresenterImpl;
import tsomaia.ia.ge.mbank.ui.mainactivity.MainActivity;

public class LogInActivity extends AppCompatActivity implements MainContract.MainView {

    private TextInputEditText username;
    private TextInputEditText password;
    private Button logInButton;
    private String passUsername;
    private String passPassword;

    private boolean showToast;
    private MainContract.Presenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        logInButton = findViewById(R.id.logInButton);

        presenter = new MainPresenterImpl(this, new GetUsersInteractorImpl());
        presenter.fetchData();

        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                passUsername = username.getText().toString();
                passPassword = password.getText().toString();
                showToast = presenter.validateUser(passUsername,passPassword);
                if(showToast){
                    Intent intent = new Intent(LogInActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                else
                showToast();
            }
        });
    }

    @Override
    public void showToast(){
            Toast.makeText(LogInActivity.this, "მომხმარებლის სახელი და პაროლი არ უნდა იყოს 3 სიმბოლოზე ნაკლები", Toast.LENGTH_SHORT).show();

    }

}
