package tsomaia.ia.ge.mbank.ui.loginpage;

public interface MainContract {

    interface Presenter {
        void fetchData();
        boolean validateUser(String username, String password);

    }
    interface MainView {

        void showToast();

    }

    interface GetUsersIntractor {

        interface OnFinishedListener {
            void onFinished(String SessionID);
            void onFailure(Throwable t);

        }
        void getUsersList(OnFinishedListener onFinishedListener);
    }

}
