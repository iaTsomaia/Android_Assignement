package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.v4.app.Fragment;

public class FragmentAssets extends Fragment {



}
