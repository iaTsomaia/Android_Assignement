package tsomaia.ia.ge.mbank.ui;

public class UI {
}
