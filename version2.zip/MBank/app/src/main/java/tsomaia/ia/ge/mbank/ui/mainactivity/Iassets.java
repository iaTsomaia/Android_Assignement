package tsomaia.ia.ge.mbank.ui.mainactivity;

public interface Iassets {
    Double getBaseAmount();
    String getProductName();

}
