package tsomaia.ia.ge.mbank.models.cards;

public class Card {
    private Integer Id;
    private Integer CardId;
    private Integer AcctKey;
    private Integer ClientKey;
    private String CardClass;
    private String CardName;
    private String CardType;
    private String ProductCode;
    private String SubProductCode;
    private String SubProductGroup;
    private String LastFour;
    private String CardHolder;
    private Integer ExpDate;
    private String IsCardBlocked;
    private String CardPan;
    private String CardForTypeDictionaryValue;
    private String ProductGroup;
    private Integer ProductId;
    private Integer SubProductId;
    private String NameDictionaryValue;


    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public Integer getCardId() {
        return CardId;
    }

    public void setCardId(Integer cardId) {
        CardId = cardId;
    }

    public Integer getAcctKey() {
        return AcctKey;
    }

    public void setAcctKey(Integer acctKey) {
        AcctKey = acctKey;
    }

    public Integer getClientKey() {
        return ClientKey;
    }

    public void setClientKey(Integer clientKey) {
        ClientKey = clientKey;
    }

    public String getCardClass() {
        return CardClass;
    }

    public void setCardClass(String cardClass) {
        CardClass = cardClass;
    }

    public String getCardName() {
        return CardName;
    }

    public void setCardName(String cardName) {
        CardName = cardName;
    }

    public String getCardType() {
        return CardType;
    }

    public void setCardType(String cardType) {
        CardType = cardType;
    }

    public String getProductCode() {
        return ProductCode;
    }

    public void setProductCode(String productCode) {
        ProductCode = productCode;
    }

    public String getSubProductCode() {
        return SubProductCode;
    }

    public void setSubProductCode(String subProductCode) {
        SubProductCode = subProductCode;
    }

    public String getSubProductGroup() {
        return SubProductGroup;
    }

    public void setSubProductGroup(String subProductGroup) {
        SubProductGroup = subProductGroup;
    }

    public String getLastFour() {
        return LastFour;
    }

    public void setLastFour(String lastFour) {
        LastFour = lastFour;
    }

    public String getCardHolder() {
        return CardHolder;
    }

    public void setCardHolder(String cardHolder) {
        CardHolder = cardHolder;
    }

    public Integer getExpDate() {
        return ExpDate;
    }

    public void setExpDate(Integer expDate) {
        ExpDate = expDate;
    }

    public String getIsCardBlocked() {
        return IsCardBlocked;
    }

    public void setIsCardBlocked(String isCardBlocked) {
        IsCardBlocked = isCardBlocked;
    }

    public String getCardPan() {
        return CardPan;
    }

    public void setCardPan(String cardPan) {
        CardPan = cardPan;
    }

    public String getCardForTypeDictionaryValue() {
        return CardForTypeDictionaryValue;
    }

    public void setCardForTypeDictionaryValue(String cardForTypeDictionaryValue) {
        CardForTypeDictionaryValue = cardForTypeDictionaryValue;
    }

    public String getProductGroup() {
        return ProductGroup;
    }

    public void setProductGroup(String productGroup) {
        ProductGroup = productGroup;
    }

    public Integer getProductId() {
        return ProductId;
    }

    public void setProductId(Integer productId) {
        ProductId = productId;
    }

    public Integer getSubProductId() {
        return SubProductId;
    }

    public void setSubProductId(Integer subProductId) {
        SubProductId = subProductId;
    }

    public String getNameDictionaryValue() {
        return NameDictionaryValue;
    }

    public void setNameDictionaryValue(String nameDictionaryValue) {
        NameDictionaryValue = nameDictionaryValue;
    }
}
