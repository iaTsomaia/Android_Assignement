package tsomaia.ia.ge.mbank.models.login;

import java.util.List;

public class SessionInfo {
    private String SessionId;
    private List<SessionDetails> SessionDetails;
    private List<UserDetails> UserDetails;


    public String getSessionId() {
        return SessionId;
    }

    public void setSessionId(String sessionId) {
        SessionId = sessionId;
    }

    public List<tsomaia.ia.ge.mbank.models.login.SessionDetails> getSessionDetails() {
        return SessionDetails;
    }

    public void setSessionDetails(List<tsomaia.ia.ge.mbank.models.login.SessionDetails> sessionDetails) {
        SessionDetails = sessionDetails;
    }

    public List<tsomaia.ia.ge.mbank.models.login.UserDetails> getUserDetails() {
        return UserDetails;
    }

    public void setUserDetails(List<tsomaia.ia.ge.mbank.models.login.UserDetails> userDetails) {
        UserDetails = userDetails;
    }
}


