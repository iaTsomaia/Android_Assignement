package tsomaia.ia.ge.mbank.models.history;

import java.util.List;

public class TransactionsSummary {
    private Double OutcomeSum;
    private Double IncomeSum;
    private List<MyOperations> MyOperations;

    public Double getOutcomeSum() {
        return OutcomeSum;
    }

    public void setOutcomeSum(Double outcomeSum) {
        OutcomeSum = outcomeSum;
    }

    public Double getIncomeSum() {
        return IncomeSum;
    }

    public void setIncomeSum(Double incomeSum) {
        IncomeSum = incomeSum;
    }

    public List<tsomaia.ia.ge.mbank.models.history.MyOperations> getMyOperations() {
        return MyOperations;
    }

    public void setMyOperations(List<tsomaia.ia.ge.mbank.models.history.MyOperations> myOperations) {
        MyOperations = myOperations;
    }
}

