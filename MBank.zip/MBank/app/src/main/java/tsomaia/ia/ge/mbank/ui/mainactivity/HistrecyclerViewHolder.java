package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.history.MyOperations;
import tsomaia.ia.ge.mbank.models.history.TransactionsSummary;

public class HistrecyclerViewHolder extends RecyclerView.ViewHolder {
    private TextView dateHist;
    private TextView companyHist;
    private TextView operationTypeHist;
    private TextView amountHist;
    public HistrecyclerViewHolder(@NonNull View itemView) {
        super(itemView);
        dateHist = itemView.findViewById(R.id.dateHist);
        companyHist = itemView.findViewById(R.id.companyHist);
        operationTypeHist = itemView.findViewById(R.id.operationTypeHist);
        amountHist = itemView.findViewById(R.id.amountHist);

    }
    public void setHistRecyclerData(MyOperations myOperations){
        Date date=new Date(myOperations.getDate());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yy");
        String dateText = simpleDateFormat.format(date);

        dateHist.setText(dateText);
        if (myOperations.getEntryGroupName().toString().equals("გადახდა"))
             companyHist.setText(myOperations.getMerchantName());
        else if (myOperations.getEntryGroup().toString().equals("IN_TRANSFER") || myOperations.getEntryGroup().toString().equals("OUT_TRANSFER"))
            companyHist.setText(myOperations.getBeneficiary().toString());
         else if (myOperations.getEntryGroupName().toString().equals("სესხის დაფარვა"))
             companyHist.setText("სესხი");




        operationTypeHist.setText(myOperations.getEntryGroupName());
        if (myOperations.getEntryGroup().toString().equals("IN_TRANSFER"))
            amountHist.setText(myOperations.getAmount().toString() + " " + "ლარი");
        else
        amountHist.setText("-" + myOperations.getAmount().toString() + " " + "ლარი");
    }
}
