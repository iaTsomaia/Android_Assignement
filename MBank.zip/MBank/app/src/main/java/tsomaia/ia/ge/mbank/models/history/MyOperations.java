package tsomaia.ia.ge.mbank.models.history;


public class MyOperations {

      private Long AcctKey;
      private Long EntryId;
      private String Nomination;
      private String EntryGroup;
      private String MerchantId;
      private Long Date;
      private Double Amount;
      private String Ccy;
      private String DocNomination;
      private String Beneficiary;
      private String DstAcc;
      private String SrcAcc;
      private String MerchantName;
      private String MerchantNameInt;
      private Double AmountBase;
      private String EntryGroupName;
      private Integer EntryGroupNameId;
      private String ServiceId;
      private Long PostDate;


    public Long getAcctKey() {
        return AcctKey;
    }

    public void setAcctKey(Long acctKey) {
        AcctKey = acctKey;
    }

    public Long getEntryId() {
        return EntryId;
    }

    public void setEntryId(Long entryId) {
        EntryId = entryId;
    }

    public String getNomination() {
        return Nomination;
    }

    public void setNomination(String nomination) {
        Nomination = nomination;
    }

    public String getEntryGroup() {
        return EntryGroup;
    }

    public void setEntryGroup(String entryGroup) {
        EntryGroup = entryGroup;
    }

    public String getMerchantId() {
        return MerchantId;
    }

    public void setMerchantId(String merchantId) {
        MerchantId = merchantId;
    }

    public Long getDate() {
        return Date;
    }

    public void setDate(Long date) {
        Date = date;
    }

    public Double getAmount() {
        return Amount;
    }

    public void setAmount(Double amount) {
        Amount = amount;
    }

    public String getCcy() {
        return Ccy;
    }

    public void setCcy(String ccy) {
        Ccy = ccy;
    }

    public String getDocNomination() {
        return DocNomination;
    }

    public void setDocNomination(String docNomination) {
        DocNomination = docNomination;
    }

    public String getBeneficiary() {
        return Beneficiary;
    }

    public void setBeneficiary(String beneficiary) {
        Beneficiary = beneficiary;
    }

    public String getDstAcc() {
        return DstAcc;
    }

    public void setDstAcc(String dstAcc) {
        DstAcc = dstAcc;
    }

    public String getSrcAcc() {
        return SrcAcc;
    }

    public void setSrcAcc(String srcAcc) {
        SrcAcc = srcAcc;
    }

    public String getMerchantName() {
        return MerchantName;
    }

    public void setMerchantName(String merchantName) {
        MerchantName = merchantName;
    }

    public String getMerchantNameInt() {
        return MerchantNameInt;
    }

    public void setMerchantNameInt(String merchantNameInt) {
        MerchantNameInt = merchantNameInt;
    }

    public Double getAmountBase() {
        return AmountBase;
    }

    public void setAmountBase(Double amountBase) {
        AmountBase = amountBase;
    }

    public String getEntryGroupName() {
        return EntryGroupName;
    }

    public void setEntryGroupName(String entryGroupName) {
        EntryGroupName = entryGroupName;
    }

    public Integer getEntryGroupNameId() {
        return EntryGroupNameId;
    }

    public void setEntryGroupNameId(Integer entryGroupNameId) {
        EntryGroupNameId = entryGroupNameId;
    }

    public String getServiceId() {
        return ServiceId;
    }

    public void setServiceId(String serviceId) {
        ServiceId = serviceId;
    }

    public Long getPostDate() {
        return PostDate;
    }

    public void setPostDate(Long postDate) {
        PostDate = postDate;
    }
}

