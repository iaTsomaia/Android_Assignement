package tsomaia.ia.ge.mbank.rest;


import retrofit2.Call;
import retrofit2.http.GET;

import retrofit2.http.Path;

import tsomaia.ia.ge.mbank.models.history.TransactionsSummary;
import tsomaia.ia.ge.mbank.models.login.SessionInfo;
import tsomaia.ia.ge.mbank.models.profile.ClientInfo;

public interface Api {

    @GET("Clients/Login/{username}/{password}")
    Call<SessionInfo> getUsers(@Path("username") String username, @Path("password") String password);

    @GET("Clients/ClientInfo/{sessionId}")
    Call<ClientInfo> getClientInfo(@Path("sessionId") String sessionId);

    @GET("Products/Transactions/{sessionId}")
    Call<TransactionsSummary> getTransactionInfo(@Path("sessionId") String sessionId);



}
