package tsomaia.ia.ge.mbank.ui.loginpage.implementations;

import java.util.List;

import tsomaia.ia.ge.mbank.ui.loginpage.MainContract;


public class MainPresenterImpl implements MainContract.Presenter {
    private  MainContract.MainView view = null;
    private MainContract.GetUsersIntractor intractor;
    private String sessionId;
    public MainPresenterImpl(MainContract.MainView view, MainContract.GetUsersIntractor intractor){
        this.view = view;
        this.intractor = intractor;

    }
    @Override
    public void fetchData() {
         intractor.getUsersList(new MainContract.GetUsersIntractor.OnFinishedListener() {
             @Override
             public void onFinished(String SessionID) {
                         sessionId = SessionID;
             }

             @Override
             public void onFailure(Throwable t) {

             }
         });
    }

    @Override
    public boolean validateUser(String username, String password) {
           if (username.length() >= 4 && password.length() >=4 )
               return true;
           else
               return false;

    }
}
