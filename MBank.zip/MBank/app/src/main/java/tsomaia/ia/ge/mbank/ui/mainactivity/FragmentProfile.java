package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.profile.ClientInfo;
import tsomaia.ia.ge.mbank.rest.Api;
import tsomaia.ia.ge.mbank.rest.RetrofitInstance;

public class FragmentProfile  extends Fragment {
    private TextView clientName;
    private TextView clientSurname;
    private TextView clientGender;
    private TextView clientBirthDate;
    private TextView clientCategory;

    private TextView clientPhoneNum;
    private TextView clientAddress;
    private TextView clientEmailAdrress;

    private Api api;

    public static FragmentProfile newInstance(int index) {
    Bundle args = new Bundle();
    FragmentProfile fragment = new FragmentProfile();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);


        clientName = view.findViewById(R.id.clientName);
        clientSurname = view.findViewById(R.id.clientSurname);
        clientGender = view.findViewById(R.id.clientGender);
        clientBirthDate = view.findViewById(R.id.clientBirthDate);
        clientCategory = view.findViewById(R.id.clientCategory);
        clientPhoneNum = view.findViewById(R.id.clientPhoneNum);
        clientAddress = view.findViewById(R.id.clientAddress);
        clientEmailAdrress = view.findViewById(R.id.clientEmailAddress);

        api = RetrofitInstance.getRetrofitInstance().create(Api.class);
        String test = "AQIC5wM2LY4Sfczsz_vdCMso9AWlYSTzVn8a1cm3YCJ48DM.*AAJTSQACMDE.*";

        api.getClientInfo(test).enqueue(new Callback<ClientInfo>() {
            @Override
            public void onResponse(Call<ClientInfo> call, Response<ClientInfo> response) {
                if (response.isSuccessful()) {
                    clientName.setText(response.body().getClient().getFirstName());
                    clientSurname.setText(response.body().getClient().getLastName());
                    clientGender.setText(response.body().getClient().getSex().toString());
                   clientBirthDate.setText(response.body().getClient().getBirthDate().toString());
                    clientCategory.setText(response.body().getClient().getClientCategory().toString());
                   clientPhoneNum.setText(response.body().getClientPhones().get(0).getMobile());
                    clientAddress.setText(response.body().getClientAddresses().get(0).getStreet());
                    clientEmailAdrress.setText(response.body().getClientMails().get(0).getMail());

                }
                else
                    Log.d("testtest", "errorTest");
            }

            @Override
            public void onFailure(Call<ClientInfo> call, Throwable t) {

            }
        });


        return view;
    }
}