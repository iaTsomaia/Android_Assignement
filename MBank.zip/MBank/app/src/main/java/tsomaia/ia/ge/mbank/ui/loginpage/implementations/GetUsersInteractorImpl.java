package tsomaia.ia.ge.mbank.ui.loginpage.implementations;

        import retrofit2.Call;
        import retrofit2.Callback;
        import retrofit2.Response;
        import tsomaia.ia.ge.mbank.rest.Api;
        import tsomaia.ia.ge.mbank.ui.loginpage.MainContract;
        import tsomaia.ia.ge.mbank.rest.RetrofitInstance;
        import tsomaia.ia.ge.mbank.models.login.SessionInfo;

public class GetUsersInteractorImpl implements MainContract.GetUsersIntractor {

    private Api api;
    private String username , password;
    @Override
    public void getUsersList(final OnFinishedListener onFinishedListener) {
        api = RetrofitInstance.getRetrofitInstance().create(Api.class);
        username = "sdfdsf";
           password = "asvjnk";

        api.getUsers(username, password).enqueue(new Callback<SessionInfo>() {
            @Override
            public void onResponse(Call<SessionInfo> call, Response<SessionInfo> response) {
                onFinishedListener.onFinished(response.body().getSessionId());
            }

            @Override
            public void onFailure(Call<SessionInfo> call, Throwable t) {

            }
        });
    }

}

