package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.assetsandliabilities.AssetsAndLiabilities;
import tsomaia.ia.ge.mbank.models.history.MyOperations;

public class AssetsRecyclerViewAdapter extends RecyclerView.Adapter {

    private List<Object> data = new ArrayList<>();

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;

                if (i == 0) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_assets_header, viewGroup, false);
            return new AssetsRecyclerViewHolderHeader(view);
        }
        else {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_assets_body, viewGroup, false);
            return new AssetsRecyclerViewHolder(view)  ;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (data.get(i) instanceof String)
            ((AssetsRecyclerViewHolderHeader)viewHolder).setHeaderRecyclerData(data.get(i).toString());
        else
            ((AssetsRecyclerViewHolder)viewHolder).setHeaderRecyclerData((Iassets)data.get(i));
    }

    @Override
    public int getItemViewType(int position) {
          if (data.get(position) instanceof String)
        return 0;
          else
        return 1;
    }

    @Override
    public int getItemCount() {

        return data.size();
    }
    public void setData(AssetsAndLiabilities data) {
        this.data.clear();
        notifyDataSetChanged();

        this.data.add("აქტივები");
        this.data.addAll(data.getAssets());

        this.data.add("ვალდებულებები");
        this.data.addAll(data.getLiabilities());

        this.data.add("ქულები");
        this.data.addAll(data.getPoints());

        this.data.add("საერთო რაოდენობა");
        this.data.addAll(data.getAvailableAmounts());

    }
    }


