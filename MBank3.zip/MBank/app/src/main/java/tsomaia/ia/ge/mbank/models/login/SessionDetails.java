package tsomaia.ia.ge.mbank.models.login;

class SessionDetails {
    private boolean IsChannelActive;
    private Integer SessionTimeout;

    public boolean isChannelActive() {
        return IsChannelActive;
    }

    public void setChannelActive(boolean channelActive) {
        IsChannelActive = channelActive;
    }

    public Integer getSessionTimeout() {
        return SessionTimeout;
    }

    public void setSessionTimeout(Integer sessionTimeout) {
        SessionTimeout = sessionTimeout;
    }
}


