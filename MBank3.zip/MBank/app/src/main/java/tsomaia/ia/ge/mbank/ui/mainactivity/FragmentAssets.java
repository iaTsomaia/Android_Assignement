package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.assetsandliabilities.AssetsAndLiabilities;
import tsomaia.ia.ge.mbank.models.history.TransactionsSummary;
import tsomaia.ia.ge.mbank.rest.Api;
import tsomaia.ia.ge.mbank.rest.RetrofitInstance;

public class FragmentAssets extends Fragment {
    private Api api;
    private RecyclerView recyclerView;
    private AssetsRecyclerViewAdapter assetsRecyclerViewAdapter;


    public static FragmentAssets newInstance(int index) {
        Bundle args = new Bundle();
        FragmentAssets fragment = new FragmentAssets();
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_assets, container, false);

        recyclerView = view.findViewById(R.id.assetsRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        assetsRecyclerViewAdapter = new AssetsRecyclerViewAdapter();
        recyclerView.setAdapter(assetsRecyclerViewAdapter);

              api = RetrofitInstance.getRetrofitInstance().create(Api.class);
        String test = "AQIC5wM2LY4Sfczsz_vdCMso9AWlYSTzVn8a1cm3YCJ48DM.*AAJTSQACMDE.*";

        api.getAssets(test).enqueue(new Callback<AssetsAndLiabilities>() {


            @Override
            public void onResponse(Call<AssetsAndLiabilities> call, Response<AssetsAndLiabilities> response) {
                if (response.isSuccessful()) {
                    assetsRecyclerViewAdapter.setData(response.body());
                }
            }

            @Override
            public void onFailure(Call<AssetsAndLiabilities> call, Throwable t) {
                Log.d("arwamoigo",t.getMessage());
            }
        });

        return view;
    }
}




