package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.assetsandliabilities.AssetsAndLiabilities;
import tsomaia.ia.ge.mbank.models.cards.Card;
import tsomaia.ia.ge.mbank.rest.Api;
import tsomaia.ia.ge.mbank.rest.RetrofitInstance;

public class FragmentCards extends Fragment {
    private Api api;
    private RecyclerView recyclerView;
    private CardsRecyclerViewAdapter cardsRecyclerViewAdapter;


    public static FragmentCards newInstance(int index) {
        Bundle args = new Bundle();
        FragmentCards fragment = new FragmentCards();
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cards, container, false);

        recyclerView = view.findViewById(R.id.cardsRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        cardsRecyclerViewAdapter = new CardsRecyclerViewAdapter();
        recyclerView.setAdapter(cardsRecyclerViewAdapter);

        api = RetrofitInstance.getRetrofitInstance().create(Api.class);
        String test = "AQIC5wM2LY4Sfczsz_vdCMso9AWlYSTzVn8a1cm3YCJ48DM.*AAJTSQACMDE.*";

        api.getCards(test).enqueue(new Callback<List<Card>>() {
            @Override
            public void onResponse(Call<List<Card>> call, Response<List<Card>> response) {
                cardsRecyclerViewAdapter.setData(response.body());
            }

            @Override
            public void onFailure(Call<List<Card>> call, Throwable t) {

            }
        });

        return view;
    }
}


