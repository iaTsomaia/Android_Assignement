package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;

import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.assetsandliabilities.*;

public class AssetsRecyclerViewHolderHeader extends RecyclerView.ViewHolder {
    private TextView header;

    public AssetsRecyclerViewHolderHeader(@NonNull View itemView) {
        super(itemView);
        header = itemView.findViewById(R.id.assetsHeader);
            }

    public void setHeaderRecyclerData(String header){

        this.header.setText(header);

    }


}
