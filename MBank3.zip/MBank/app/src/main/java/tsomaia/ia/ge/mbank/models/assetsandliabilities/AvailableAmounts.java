package tsomaia.ia.ge.mbank.models.assetsandliabilities;

import tsomaia.ia.ge.mbank.ui.mainactivity.Iassets;

public class AvailableAmounts implements Iassets {
    private String ProductType;
    private Double AmountBase;
    private String ProductName;


    public String getProductType() {
        return ProductType;
    }

    public void setProductType(String productType) {
        ProductType = productType;
    }

    public Double getAmountBase() {
        return AmountBase;
    }

    public void setAmountBase(Double amountBase) {
        AmountBase = amountBase;
    }

    @Override
    public Double getBaseAmount() {
        return AmountBase;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }
}



