package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.history.TransactionsSummary;
import tsomaia.ia.ge.mbank.rest.Api;
import tsomaia.ia.ge.mbank.rest.RetrofitInstance;

public class FragmentHistory extends Fragment {
    private Api api;
    private RecyclerView recyclerView;
    private HistRecyclerViewAdapter histRecyclerViewAdapter;
    private TextView income;
    private TextView outgoings;


    public static FragmentHistory newInstance(int index) {
        Bundle args = new Bundle();
        FragmentHistory fragment = new FragmentHistory();
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);

        recyclerView = view.findViewById(R.id.histRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        histRecyclerViewAdapter = new HistRecyclerViewAdapter();
        recyclerView.setAdapter(histRecyclerViewAdapter);

        income = view.findViewById(R.id.income);
        outgoings = view.findViewById(R.id.outgoings);

        api = RetrofitInstance.getRetrofitInstance().create(Api.class);
        String test = "AQIC5wM2LY4Sfczsz_vdCMso9AWlYSTzVn8a1cm3YCJ48DM.*AAJTSQACMDE.*";

        api.getTransactionInfo(test).enqueue(new Callback<TransactionsSummary>() {


            @Override
            public void onResponse(Call<TransactionsSummary> call, Response<TransactionsSummary> response) {
                if (response.isSuccessful()) {
                    histRecyclerViewAdapter.setData(response.body().getMyOperations());
                    income.setText(response.body().getIncomeSum().toString());
                    outgoings.setText(response.body().getOutcomeSum().toString());
                }
            }

            @Override
            public void onFailure(Call<TransactionsSummary> call, Throwable t) {
              Log.d("arwamoigo",t.getMessage());
            }
        });

        return view;
    }
}


