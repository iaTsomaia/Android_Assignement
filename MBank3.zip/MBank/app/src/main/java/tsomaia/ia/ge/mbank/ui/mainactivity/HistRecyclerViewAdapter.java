package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.history.MyOperations;
import tsomaia.ia.ge.mbank.models.history.TransactionsSummary;


public class HistRecyclerViewAdapter extends  RecyclerView.Adapter<HistrecyclerViewHolder>  {

    private List<MyOperations> data = new ArrayList<>();

    @NonNull
    @Override
    public HistrecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_history, viewGroup, false);

        return new HistrecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistrecyclerViewHolder histrecyclerViewHolder, int i) {
        histrecyclerViewHolder.setHistRecyclerData(data.get(i));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
    public void setData(List<MyOperations> data) {
        this.data.clear();
        this.data.addAll(data);
        notifyDataSetChanged();
    }
}
