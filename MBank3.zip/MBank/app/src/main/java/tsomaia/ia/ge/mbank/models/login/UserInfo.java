package tsomaia.ia.ge.mbank.models.login;

public class UserInfo {

}
