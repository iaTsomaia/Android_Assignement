package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.cards.Card;
import tsomaia.ia.ge.mbank.models.history.MyOperations;

public class CardsRecyclerViewAdapter extends RecyclerView.Adapter<CardsRecyclerViewHolder> {

    private List<Card> data = new ArrayList<>();
    @NonNull
    @Override
    public CardsRecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_cards, viewGroup, false);
        return new CardsRecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CardsRecyclerViewHolder cardsRecyclerViewHolder, int i) {
        cardsRecyclerViewHolder.setRecyclerData(data.get(i));

    }

    @Override
    public int getItemCount() {
        return data.size();
    }
    public void setData(List<Card> data) {
        this.data.clear();
        this.data.addAll(data);
        notifyDataSetChanged();
    }
}
