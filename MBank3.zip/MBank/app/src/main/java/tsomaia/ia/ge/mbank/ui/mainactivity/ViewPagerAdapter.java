package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {
    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        if (i == 0 )
            return  FragmentProfile.newInstance(i);
        else if (i== 2)
            return  FragmentHistory.newInstance(i);
        else if (i==1)
            return FragmentAssets.newInstance(i);
        else
            return FragmentCards.newInstance(i);


    }

    @Override
    public int getCount() {
        return 4;
    }
    public CharSequence getPageTitle(int position) {
        switch (position)
        {
            case 0:
                return "პროფილი";
            case 1:
                return "აქტივები";
            case 2:
                return "გადახდების ისტორია";
            default:
                return "ბარათები";

        }
    }

}
