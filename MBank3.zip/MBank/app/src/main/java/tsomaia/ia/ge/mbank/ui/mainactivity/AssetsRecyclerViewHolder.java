package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import tsomaia.ia.ge.mbank.R;

public class AssetsRecyclerViewHolder extends RecyclerView.ViewHolder {

    private TextView productName;
    private TextView assetsAmount;
    public AssetsRecyclerViewHolder(@NonNull View itemView) {
        super(itemView);
        productName = itemView.findViewById(R.id.productName);
        assetsAmount = itemView.findViewById(R.id.assetsAmount);
    }
    public void setHeaderRecyclerData(Iassets data){

        productName.setText(data.getProductName());
        assetsAmount.setText(data.getBaseAmount().toString());

    }

}
