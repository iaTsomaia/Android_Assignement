package tsomaia.ia.ge.mbank.ui.mainactivity;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

import tsomaia.ia.ge.mbank.R;
import tsomaia.ia.ge.mbank.models.cards.Card;

public class CardsRecyclerViewHolder extends RecyclerView.ViewHolder {

    private TextView clientType;
    private ImageView cardType;
    private TextView cardCode;
    private TextView expiryDate;
    private TextView cardOwner;
    private RelativeLayout relativeLayout;


    public CardsRecyclerViewHolder(@NonNull View itemView) {
        super(itemView);
        clientType = itemView.findViewById(R.id.clientType);
        cardType = itemView.findViewById(R.id.cardType);
        cardCode = itemView.findViewById(R.id.cardCode);
        expiryDate = itemView.findViewById(R.id.expiryDate);
        cardOwner = itemView.findViewById(R.id.cardOwner);
        relativeLayout = itemView.findViewById(R.id.cardImage);

    }
    public void setRecyclerData(Card card){
        Date date=new Date(card.getExpDate());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/yy");
        String dateText = simpleDateFormat.format(date);

        clientType.setText(card.getCardClass().toString());

        if (card.getCardClass().equals("VISA"))
        cardType.setImageResource(R.drawable.card_icon_visa_border_single);
        else
        cardType.setImageResource(R.drawable.card_icon_amex_single);

        cardCode.setText("XXXX XXXX XXXX " + card.getLastFour());
        expiryDate.setText(dateText);
        cardOwner.setText(card.getCardHolder());

        if (card.getCardType().equals("SOLOP_CARD"))
        relativeLayout.setBackgroundResource(R.drawable.account_background_solo);
        else if (card.getCardType().equals("GOLD-IPOPW"))
        relativeLayout.setBackgroundResource(R.drawable.account_background_visa_gold);
        else
        relativeLayout.setBackgroundResource(R.drawable.account_background_amex_green);







    }

}

