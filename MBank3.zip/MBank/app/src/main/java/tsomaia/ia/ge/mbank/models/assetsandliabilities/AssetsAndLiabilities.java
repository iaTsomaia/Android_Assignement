package tsomaia.ia.ge.mbank.models.assetsandliabilities;

import java.util.List;


public class AssetsAndLiabilities {
      private List<Points> Points;
      private List<Assets> Assets;
      private List<Liabilities> Liabilities;
      private List<AvailableAmounts> AvailableAmounts;

    public List<tsomaia.ia.ge.mbank.models.assetsandliabilities.Points> getPoints() {
        return Points;
    }

    public void setPoints(List<tsomaia.ia.ge.mbank.models.assetsandliabilities.Points> points) {
        Points = points;
    }

    public List<tsomaia.ia.ge.mbank.models.assetsandliabilities.Assets> getAssets() {
        return Assets;
    }

    public void setAssets(List<tsomaia.ia.ge.mbank.models.assetsandliabilities.Assets> assets) {
        Assets = assets;
    }

    public List<tsomaia.ia.ge.mbank.models.assetsandliabilities.Liabilities> getLiabilities() {
        return Liabilities;
    }

    public void setLiabilities(List<tsomaia.ia.ge.mbank.models.assetsandliabilities.Liabilities> liabilities) {
        Liabilities = liabilities;
    }

    public List<tsomaia.ia.ge.mbank.models.assetsandliabilities.AvailableAmounts> getAvailableAmounts() {
        return AvailableAmounts;
    }

    public void setAvailableAmounts(List<tsomaia.ia.ge.mbank.models.assetsandliabilities.AvailableAmounts> availableAmounts) {
        AvailableAmounts = availableAmounts;
    }
}


