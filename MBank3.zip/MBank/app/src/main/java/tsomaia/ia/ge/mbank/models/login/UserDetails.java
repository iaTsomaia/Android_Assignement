package tsomaia.ia.ge.mbank.models.login;

class UserDetails {
    private Integer UserId;
    private String Username;
    private String Name;
    private String LastName;
    private String PhoneForSms;
    private Boolean Active;

    public Integer getUserId() {
        return UserId;
    }

    public void setUserId(Integer userId) {
        UserId = userId;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhoneForSms() {
        return PhoneForSms;
    }

    public void setPhoneForSms(String phoneForSms) {
        PhoneForSms = phoneForSms;
    }

    public Boolean getActive() {
        return Active;
    }

    public void setActive(Boolean active) {
        Active = active;
    }
}


